app

.component('mealPlan', {
  templateUrl: 'partials/mealPlan.html',
  controller: 'mealPlanCtrl'
})

.component('carbs', {
  templateUrl: 'partials/carbs.html',
  controller: 'carbCtrl'
})

.component('nonCarbs', {
  templateUrl: 'partials/nonCarbs.html',
  controller: 'nonCarbCtrl'
});